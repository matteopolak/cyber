### Setup
* Run the following command, then analyze `diff.txt`:
```shell
$ bash find.sh
```